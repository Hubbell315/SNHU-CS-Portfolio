// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// custom exception used for application specific errors
class ApplicationException : public std::exception
{

public:

    // return the custom exception message
    const char* what() const noexcept override
    {
        return "application specific exception";
    }

};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // throw standard exception to simulate an application error
    throw std::runtime_error("application logic failed during processing");
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        // run additional application logic
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    // catch standard exception and display the error message
    catch (const std::exception& ex)
    {
        std::cout << "Application Error: "
                  << ex.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // throw custom exception for main to handle
    throw ApplicationException();
}

float divide(float num, float den)
{
    // prevent divide by zero
    if (den == 0)
    {
        throw std::overflow_error("Cannot divide by zero.");
    }

    return num / den;
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        // attempt division operation
        auto result = divide(numerator, denominator);

        std::cout << "divide(" << numerator
                  << ", " << denominator
                  << ") = " << result << std::endl;
    }

    // only catch exception thrown by divide
    catch (const std::overflow_error& ex)
    {
        std::cout << "Division Error: "
                  << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        // wrap application in top level try block
        do_division();
        do_custom_application_logic();
    }

    // catch the custom application exception first
    catch (const ApplicationException& ex)
    {
        std::cout << "Application Exception: "
                  << ex.what() << std::endl;
    }

    // catch remaining standard exceptions
    catch (const std::exception& ex)
    {
        std::cout << "Standard Exception: "
                  << ex.what() << std::endl;
    }

    // catch unexpected exceptions
    catch (...)
    {
        std::cout << "Unknown exception caught." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu