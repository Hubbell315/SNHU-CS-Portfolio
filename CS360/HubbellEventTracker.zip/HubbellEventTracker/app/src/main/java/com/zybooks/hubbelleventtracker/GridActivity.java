package com.zybooks.hubbelleventtracker;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/*
Title: GridActivity.java

Purpose:
    Displays all events for the logged-in user in a grid layout.
    Handles add, edit, and delete operations.

Key Responsibilities:
    - Load user-scoped events from database
    - Display events using RecyclerView
    - Provide dialog for creating and editing events
    - Navigate to SMS settings screen

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15
*/

public class GridActivity extends AppCompatActivity {

    private DBHelper db;

    private RecyclerView rvEvents;
    private Button btnAddEvent;
    private Button btnSmsSettings;

    private final ArrayList<Event> events = new ArrayList<>();
    private EventAdapter adapter;

    private String currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_grid);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.grid_root), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db = new DBHelper(this);

        currentUser = getSharedPreferences("session", MODE_PRIVATE)
                .getString("current_user", null);

        rvEvents = findViewById(R.id.rvEvents);
        btnAddEvent = findViewById(R.id.btnAddEvent);
        btnSmsSettings = findViewById(R.id.btnSmsSettings);

        btnSmsSettings.setOnClickListener(v ->
                startActivity(new android.content.Intent(this, SMS_Notifications.class))
        );

        rvEvents.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new EventAdapter(events, new EventAdapter.Listener() {
            @Override
            public void onEdit(Event e) {
                showEventDialog(true, e);
            }

            @Override
            public void onDelete(Event e) {
                boolean ok = db.deleteEvent(e.id);

                if (ok) {
                    Toast.makeText(GridActivity.this, "Event deleted.", Toast.LENGTH_SHORT).show();
                    loadEvents();
                } else {
                    Toast.makeText(GridActivity.this, "Delete failed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rvEvents.setAdapter(adapter);

        btnAddEvent.setOnClickListener(v -> showEventDialog(false, null));

        loadEvents();
    }

    private void loadEvents() {

        events.clear();

        Cursor c = db.getAllEvents(currentUser);

        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(DBHelper.E_ID));
            String title = c.getString(c.getColumnIndexOrThrow(DBHelper.E_TITLE));
            String date = c.getString(c.getColumnIndexOrThrow(DBHelper.E_DATE));
            String location = c.getString(c.getColumnIndexOrThrow(DBHelper.E_LOCATION));
            String details = c.getString(c.getColumnIndexOrThrow(DBHelper.E_DETAILS));

            events.add(new Event(id, title, date, location, details));
        }

        c.close();
        adapter.notifyDataSetChanged();
    }

    private void showEventDialog(boolean isEdit, Event existing) {

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_event, null);

        EditText etTitle = view.findViewById(R.id.etDialogTitle);
        EditText etDate = view.findViewById(R.id.etDialogDate);
        EditText etLocation = view.findViewById(R.id.etDialogLocation);
        EditText etDetails = view.findViewById(R.id.etDialogDetails);

        if (isEdit && existing != null) {
            etTitle.setText(existing.title);
            etDate.setText(existing.date);
            etLocation.setText(existing.location);
            etDetails.setText(existing.details);
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isEdit ? "Edit Event" : "Add Event")
                .setView(view)
                .setPositiveButton(isEdit ? "Update" : "Add", null)
                .setNegativeButton("Cancel", (d, w) -> d.dismiss())
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {

                String title = etTitle.getText().toString().trim();
                String date = etDate.getText().toString().trim();
                String location = etLocation.getText().toString().trim();
                String details = etDetails.getText().toString().trim();

                if (TextUtils.isEmpty(title) || TextUtils.isEmpty(date)) {
                    Toast.makeText(this, "Title and Date are required.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!isEdit) {

                    long id = db.addEvent(title, date, location, details, currentUser);

                    if (id == -1) {
                        Toast.makeText(this, "Add failed.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Toast.makeText(this, "Event added.", Toast.LENGTH_SHORT).show();

                } else {

                    boolean ok = db.updateEvent(existing.id, title, date, location, details);

                    if (!ok) {
                        Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();
                loadEvents();
            });
        });

        dialog.show();
    }
}


