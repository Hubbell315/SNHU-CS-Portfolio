package com.zybooks.hubbelleventtracker;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

/*
Title: SMS_Notifications.java

Purpose:
    Manages SMS notification permission and user preference settings.

Key Responsibilities:
    - Request SMS permission at runtime
    - Enable or disable SMS notifications based on permission
    - Send test SMS when enabled
    - Ensure app continues functioning if permission is denied

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15
*/

public class SMS_Notifications extends AppCompatActivity {

    private static final int REQ_SMS = 2001;

    private static final String PREFS = "sms_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    private SwitchMaterial switchSms;
    private MaterialButton btnRequestPermission;
    private TextView tvSmsStatus;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        switchSms = findViewById(R.id.switchSms);
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        tvSmsStatus = findViewById(R.id.tvSmsStatus);

        refreshUi();

        btnRequestPermission.setOnClickListener(v -> requestSmsPermission());

        switchSms.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (isChecked && !hasSmsPermission()) {
                Toast.makeText(this,
                        "SMS permission required to enable notifications.",
                        Toast.LENGTH_SHORT).show();

                switchSms.setChecked(false);
                requestSmsPermission();
                return;
            }

            prefs.edit().putBoolean(KEY_SMS_ENABLED, isChecked).apply();

            if (isChecked) {
                sendTestSms();
            }

            refreshUi();
        });
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {

        if (hasSmsPermission()) {
            Toast.makeText(this,
                    "SMS permission already granted.",
                    Toast.LENGTH_SHORT).show();
            refreshUi();
            return;
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                REQ_SMS
        );
    }

    private void sendTestSms() {

        if (!hasSmsPermission()) {
            Toast.makeText(this,
                    "SMS permission not granted.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String phoneNumber = "5551234567";
            String message = "Event reminder from Hubbell Event Tracker!";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this,
                    "Test SMS sent successfully!",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this,
                    "SMS failed to send.",
                    Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void refreshUi() {

        boolean permitted = hasSmsPermission();
        boolean enabledPref = prefs.getBoolean(KEY_SMS_ENABLED, false);

        if (!permitted) {
            switchSms.setChecked(false);
            switchSms.setEnabled(false);
            tvSmsStatus.setText(
                    "SMS permission not granted. Notifications are disabled."
            );
            btnRequestPermission.setEnabled(true);
            return;
        }

        switchSms.setEnabled(true);
        btnRequestPermission.setEnabled(false);

        if (enabledPref) {
            tvSmsStatus.setText("SMS notifications are enabled.");
        } else {
            tvSmsStatus.setText(
                    "SMS permission granted, but notifications are currently OFF."
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode != REQ_SMS) return;

        boolean granted = grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            Toast.makeText(this,
                    "SMS permission granted.",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this,
                    "SMS permission denied. App will continue without SMS.",
                    Toast.LENGTH_SHORT).show();

            prefs.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
        }

        refreshUi();
    }
}







