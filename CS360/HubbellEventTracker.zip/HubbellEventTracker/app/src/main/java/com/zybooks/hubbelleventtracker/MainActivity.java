package com.zybooks.hubbelleventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/*
Title: MainActivity.java

Purpose:
    Handles user login and navigation to account creation.

Key Responsibilities:
    - Validate login credentials against database
    - Store logged-in user session
    - Navigate to GridActivity on successful login
    - Navigate to RegisterActivity for new users

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15
*/

public class MainActivity extends AppCompatActivity {

    private DBHelper db;

    private EditText etUsername;
    private EditText etPassword;

    private Button btnLogin;
    private Button btnCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login_root), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db = new DBHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnCreate = findViewById(R.id.btnCreateAccount);

        btnLogin.setOnClickListener(v -> handleLogin());

        btnCreate.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class))
        );
    }

    private void handleLogin() {

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = db.checkLogin(username, password);

        if (!ok) {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
            return;
        }

        getSharedPreferences("session", MODE_PRIVATE)
                .edit()
                .putString("current_user", username)
                .apply();

        Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

        startActivity(new Intent(this, GridActivity.class));
        finish();
    }
}


