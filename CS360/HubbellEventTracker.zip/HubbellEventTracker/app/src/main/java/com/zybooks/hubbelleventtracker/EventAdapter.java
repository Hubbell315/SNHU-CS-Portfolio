package com.zybooks.hubbelleventtracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/*
Title: EventAdapter.java

Purpose:
    RecyclerView adapter that displays event records
    and handles edit and delete actions.

Key Responsibilities:
    - Bind Event data to layout views
    - Provide edit and delete callbacks
    - Manage ViewHolder lifecycle

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15
*/

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventVH> {

    public interface Listener {
        void onEdit(Event e);
        void onDelete(Event e);
    }

    private final List<Event> events;
    private final Listener listener;

    public EventAdapter(List<Event> events, Listener listener) {
        this.events = events;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EventVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.event_item, parent, false);

        return new EventVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EventVH holder, int position) {

        Event e = events.get(position);

        holder.tvTitle.setText(e.title);
        holder.tvDate.setText("Date: " + e.date);
        holder.tvLocation.setText("Location: " + (e.location == null ? "" : e.location));

        holder.btnEdit.setOnClickListener(v -> listener.onEdit(e));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(e));
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    static class EventVH extends RecyclerView.ViewHolder {

        TextView tvTitle;
        TextView tvDate;
        TextView tvLocation;
        Button btnEdit;
        Button btnDelete;

        public EventVH(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.tvItemTitle);
            tvDate = itemView.findViewById(R.id.tvItemDate);
            tvLocation = itemView.findViewById(R.id.tvItemLocation);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}

