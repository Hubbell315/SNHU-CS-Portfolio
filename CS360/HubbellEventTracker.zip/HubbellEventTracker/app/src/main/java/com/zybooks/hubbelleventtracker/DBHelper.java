package com.zybooks.hubbelleventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
Title (path): app/src/main/java/com/zybooks/hubbelleventtracker/DBHelper.java

Purpose:
    Central database helper for the Event Tracker application.
    Manages database creation, upgrades, authentication, and
    user-scoped event CRUD operations.

Key Responsibilities:
    - Create and upgrade SQLite schema
    - Store and validate user login credentials
    - Persist event records tied to a specific user
    - Provide create, read, update, and delete operations for events

Connection Points:
    - LoginActivity
    - RegistrationActivity
    - EventListActivity
    - Add/Edit Event screens

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15

Notes:
    Events are scoped by username to ensure each user only
    sees their own data.
*/

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "event_tracker.db";
    private static final int DB_VERSION = 3;

    // Users table
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_EMAIL = "email";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // Events table
    public static final String T_EVENTS = "events";
    public static final String E_ID = "id";
    public static final String E_TITLE = "title";
    public static final String E_DATE = "date";
    public static final String E_LOCATION = "location";
    public static final String E_DETAILS = "details";
    public static final String E_USERNAME = "username";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsers =
                "CREATE TABLE " + T_USERS + " (" +
                        U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        U_EMAIL + " TEXT NOT NULL, " +
                        U_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        U_PASSWORD + " TEXT NOT NULL" +
                        ");";

        String createEvents =
                "CREATE TABLE " + T_EVENTS + " (" +
                        E_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        E_TITLE + " TEXT NOT NULL, " +
                        E_DATE + " TEXT NOT NULL, " +
                        E_LOCATION + " TEXT, " +
                        E_DETAILS + " TEXT, " +
                        E_USERNAME + " TEXT NOT NULL" +
                        ");";

        db.execSQL(createUsers);
        db.execSQL(createEvents);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_EVENTS);
        onCreate(db);
    }

    // Users

    public boolean createUser(String email, String username, String password) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(U_EMAIL, email);
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);

        long result = db.insert(T_USERS, null, cv);
        return result != -1;
    }

    public boolean checkLogin(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT " + U_ID + " FROM " + T_USERS +
                        " WHERE " + U_USERNAME + "=? AND " + U_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean ok = c.moveToFirst();
        c.close();

        return ok;
    }

    public boolean userExists(String username) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT " + U_ID + " FROM " + T_USERS +
                        " WHERE " + U_USERNAME + "=?",
                new String[]{username}
        );

        boolean exists = c.moveToFirst();
        c.close();

        return exists;
    }

    // Events

    public long addEvent(String title, String date, String location, String details, String username) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(E_TITLE, title);
        cv.put(E_DATE, date);
        cv.put(E_LOCATION, location);
        cv.put(E_DETAILS, details);
        cv.put(E_USERNAME, username);

        return db.insert(T_EVENTS, null, cv);
    }

    public Cursor getAllEvents(String username) {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                T_EVENTS,
                null,
                E_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                E_ID + " DESC"
        );
    }

    public boolean updateEvent(long id, String title, String date, String location, String details) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(E_TITLE, title);
        cv.put(E_DATE, date);
        cv.put(E_LOCATION, location);
        cv.put(E_DETAILS, details);

        int rows = db.update(T_EVENTS, cv, E_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteEvent(long id) {

        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(T_EVENTS, E_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}


