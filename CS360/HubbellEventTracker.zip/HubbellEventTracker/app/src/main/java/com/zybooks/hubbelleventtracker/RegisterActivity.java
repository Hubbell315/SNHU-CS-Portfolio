package com.zybooks.hubbelleventtracker;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
Title: RegisterActivity.java

Purpose:
    Allows a new user to create an account.

Key Responsibilities:
    - Validate registration input
    - Create new user record in database
    - Return user to login screen after successful registration

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15
*/

public class RegisterActivity extends AppCompatActivity {

    private DBHelper db;

    private EditText etEmail;
    private EditText etNewUsername;
    private EditText etNewPassword;

    private Button btnCreate;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DBHelper(this);

        etEmail = findViewById(R.id.etEmail);
        etNewUsername = findViewById(R.id.etNewUsername);
        etNewPassword = findViewById(R.id.etNewPassword);

        btnCreate = findViewById(R.id.btnCreateAccountFinal);
        btnBack = findViewById(R.id.btnBackToLogin);

        btnCreate.setOnClickListener(v -> handleCreate());
        btnBack.setOnClickListener(v -> finish());
    }

    private void handleCreate() {

        String email = etEmail.getText().toString().trim();
        String username = etNewUsername.getText().toString().trim();
        String password = etNewPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.userExists(username)) {
            Toast.makeText(this, "Username already exists. Try a different one.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = db.createUser(email, username, password);

        if (!created) {
            Toast.makeText(this, "Could not create account. Try again.", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Account created! Please log in.", Toast.LENGTH_SHORT).show();
        finish();
    }
}

