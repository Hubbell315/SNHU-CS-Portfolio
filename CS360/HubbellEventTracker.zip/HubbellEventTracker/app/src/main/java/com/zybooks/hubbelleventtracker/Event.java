package com.zybooks.hubbelleventtracker;

/*
Title (path): app/src/main/java/com/zybooks/hubbelleventtracker/Event.java

Purpose:
    Simple model class representing a single event record
    stored in the SQLite database.

Key Responsibilities:
    - Hold event data retrieved from the database
    - Provide a structured object for use in adapters and activities

Connection Points:
    - DBHelper
    - Event list adapter
    - Add/Edit Event activities

Created By:
    Tyler Hubbell

Last Updated:
    2026-02-15
*/

public class Event {

    public long id;
    public String title;
    public String date;
    public String location;
    public String details;

    public Event(long id, String title, String date, String location, String details) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.location = location;
        this.details = details;
    }
}

