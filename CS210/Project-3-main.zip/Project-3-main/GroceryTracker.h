/**
 * @file GroceryTracker.h
 * @brief Declaration of the GroceryTracker class.
 *
 * This file contains the class declaration for the GroceryTracker class, which
 * handles all the core data processing, file I/O, and reporting for the
 * Corner Grocer application. It includes public methods for interacting with
 * the data and private helper methods for internal operations.
 */

#ifndef GROCERYTRACKER_H
#define GROCERYTRACKER_H

#include <string>
#include <fstream>
#include <iostream>
#include <map>

class GroceryTracker {
    public:
        /**
         * @brief Constructs a new GroceryTracker object and processes the input file.
         *
         * @param inputFile The path to the input file containing the grocery list.
         */
        GroceryTracker(const std::string& inputFile);

        /**
         * @brief Gets the frequency of a specific item.
         *
         * @param item The name of the item to look for.
         * @return The number of times the item was purchased. Returns 0 if not found.
         */
        int getItemFrequency(const std::string& item) const;

        /**
         * @brief Prints a list of all items and their frequencies to the console.
         */
        void printAllFrequencies() const;

        /**
         * @brief Prints a text-based histogram of all item frequencies to the console.
         */
        void printHistogram() const;

    private:
        std::map<std::string, int> itemFrequencies;

        /**
         * @brief Loads grocery data from an input file.
         * @param inputFile The path to the input file.
         */
        void loadData(const std::string& inputFile);

        /**
         * @brief Creates a backup file of item frequencies.
         * @deprecated This method is deprecated in favor of a database solution.
         */
        void createBackupFile() const;
};

#endif // GROCERYTRACKER_H
