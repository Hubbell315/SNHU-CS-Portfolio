/**
 * @file Menu.cpp
 * @brief Implementation of the Menu class.
 *
 * This file contains the implementation for the methods of the Menu class,
 * which is responsible for displaying the user interface and handling
 * all user input validation for the Corner Grocer application.
 */

#include "Menu.h"
#include <iostream>
#include <limits> 
using namespace std;

/**
 * @brief Displays the main menu options to the user
 *
 * This method prints a formatted menu to the console, showing the available
 * options for the user to choose from, along with a decorative border.
 */
void Menu::displayMenu() const {
    cout << "---------------------------------------" << endl;
    cout << "          Corner Grocer Menu           " << endl;
    cout << "---------------------------------------" << endl;
    cout << "1. Look up an item's frequency" << endl;
    cout << "2. Print a list of all item frequencies" << endl;
    cout << "3. Print a histogram of all item frequencies" << endl;
    cout << "4. Exit" << endl;
    cout << "---------------------------------------" << endl;
}

/**
 * @brief Prompts the user for a menu choice and validates the input.
 *
 * This method repeatedly prompts the user for a choice until a valid
 * integer input is entered. It handles both non-integer input
 * and out-of-range integer values.
 *
 * @return The valid integer choice made by the user - 1, 2, 3, 4.
 */
int Menu::getUserChoice() const {
    int choice;
    while (true) {
        cout << "Enter your choice: ";
        if (cin >> choice) {
            if (choice >= 1 && choice <= 4) {
                return choice;
            } else {
                cout << "Invalid choice. Please enter a number between 1 and 4." << endl;
            }
        } else {
            cout << "Invalid input. Please enter a number." << endl;
            cin.clear();
            cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
        }
    }
}