Corner Grocer Item Tracking Program
Project Summary
This project involved developing a C++ program for a grocery store to analyze daily purchase records from a text file (CS210_Project_Three_Input_File.txt). 
The program provides three key functionalities: searching for the frequency of a specific item, listing all items with their purchase counts, and generating a 
text-based histogram. The primary goal was to provide the grocery store with actionable data to optimize their store layout.

Reflection
What I Did Particularly Well
I am particularly proud of my implementation of the std::map data structure to store the item frequencies. 
Using a map with string keys and int values was the most efficient way to handle the data. It allowed for quick lookups and updates as 
I processed the input file, which is a significant improvement over using a simple array or a linked list, which would require more complex search logic. 
I also made sure to create the frequency.dat backup file automatically at the beginning of the program, which was a key requirement.

Opportunities for Improvement
One area where I could enhance my code is with more robust input validation. While I did implement basic checks to ensure the user selected a menu option from 1 to 4, 
a more advanced version could handle cases where the user enters non-numeric input or special characters. I could also add more comprehensive error handling for 
file operations, such as notifying the user if the input file is missing.

The Challenge of Implementation
The most challenging part of this project was correctly implementing the file input/output (I/O) operations and correctly using the std::map in a class. 
Overcoming this challenge involved breaking down the process into smaller, manageable steps: first, ensuring the input file was read correctly, then populating the map,
and finally, writing the data to the output file. The zyBooks resources on file I/O and maps were crucial in a few cases where I needed to double-check my syntax. 
I'll definitely keep them in my support network for future projects.

Transferable Skills and Code Quality
The skills I gained from this project will be highly transferable to other projects. The core concepts of object-oriented programming, 
specifically using a class to encapsulate program logic, along with file I/O and data structures like maps, are fundamental to developing robust applications. 
The program's design, including descriptive variable names and in-line comments, makes the code maintainable for other developers to understand and adaptable to
new requirements. For instance, it would be easy to extend the program to read a different input file or to add a new menu option for more detailed analysis.
