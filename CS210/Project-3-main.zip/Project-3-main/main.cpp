/**
 * @file main.cpp
 * @brief CS 210 Project 3 - Chada Tech Corner Grocer
 *
 * @author Tyler Hubbell
 * @date 08/16/2025
 *
 * This program analyzes a list of purchased grocery items from a text file,
 * providing the user with options to look up item frequencies, print a full list,
 * or generate a text-based histogram. The program also creates a backup data
 * file for the frequencies.
 *
 * This file contains the main program entry point and orchestrates the
 * functionality of the GroceryTracker and Menu classes.
 */

#include "GroceryTracker.h"
#include "Menu.h"
using namespace std;

int main() {

    GroceryTracker tracker("CS210_Project_Three_Input_File.txt");

    Menu menu;

    int choice = 0;

    string item;

    do {
        menu.displayMenu();
        choice = menu.getUserChoice();

        switch (choice){
            case 1:
                cout << "Enter the item name you're looking for: ";
                cin >> item;
                cout << item << " " << tracker.getItemFrequency(item) << endl;
                break;           
            case 2:
                tracker.printAllFrequencies();
                break;
            case 3:
                tracker.printHistogram();
                break;
            case 4:
                cout << "Exiting, goodbye." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
        cout << endl;
    }
    while (choice != 4);
    return 0;
}
