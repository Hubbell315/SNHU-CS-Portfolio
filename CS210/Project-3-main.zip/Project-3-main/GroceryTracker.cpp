/**
 * @file GroceryTracker.cpp
 * @brief Implementation of the GroceryTracker class.
 *
 * This file contains the implementation details for all methods of the GroceryTracker class,
 * including file I/O, data processing, and output generation.
 */

#include "GroceryTracker.h"
#include <iostream>
#include <fstream>
using namespace std;

/**
 * @brief Constructs a new GroceryTracker object and processes the input file.
 *
 * The constructor initializes the object and immediately loads the data
 * from the specified file, then creates a backup file.
 *
 * @param inputFile The path to the input file containing the grocery list.
 */
GroceryTracker::GroceryTracker(const string& inputFile) {
    loadData(inputFile);
    createBackupFile();
}

/**
 * @brief Gets the frequency of a specific item.
 *
 * This method searches for a given item in the `itemFrequencies` map and
 * returns its associated count. If the item is not found, it returns 0.
 *
 * @param item The name of the item to look for.
 * @return The number of times the item was purchased.
 */
int GroceryTracker::getItemFrequency(const string& item) const {
    if (itemFrequencies.count(item)) {
        return itemFrequencies.at(item);
    }
    return 0;
}

/**
 * @brief Prints a list of all items and their frequencies.
 *
 * This method iterates through the `itemFrequencies` map and prints each
 * item's name followed by its frequency to the console.
 */
void GroceryTracker::printAllFrequencies() const {
    for (const auto & pair : itemFrequencies) {
        cout << pair.first << " " << pair.second << endl;
    }
}

/**
 * @brief Prints a text-based histogram of all item frequencies.
 *
 * This method generates a visual representation of the item frequencies
 * using asterisks, with each asterisk representing one purchase. The total
 * count is also displayed next to the histogram bar.
 */
void GroceryTracker::printHistogram() const {
    for (const auto& pair : itemFrequencies) {
        cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << " (" << pair.second << ")" << endl;
    }
}

/**
 * @brief Loads grocery data from an input file.
 *
 * This private helper method reads a file, line by line, and populates the
 * `itemFrequencies` map. It handles the case where the file cannot be opened.
 *
 * @param inputFile The path to the input file.
 */
void GroceryTracker::loadData(const string& inputFile) {
    ifstream inputStream(inputFile);
    if (!inputStream.is_open()) {
        cerr << "Error: Could not open the input file " << inputFile << endl;
        return;
    }
    string item;
    while (inputStream >> item) {
        itemFrequencies[item]++;
    }
    inputStream.close();
}

/**
 * @brief Creates a backup file of item frequencies.
 *
 * This private helper method writes the contents of the `itemFrequencies`
 * map to a new file named "frequency.dat". 
 * 
 * @deprecated This method is deprecated in favor of `saveDataToDatabase()` for scaling
 * 
 */
void GroceryTracker::createBackupFile() const {
    ofstream outputStream("frequency.dat");
    if (!outputStream.is_open()) {
        cerr << "Error: Could not create the backup file frequency.dat" << endl;
        return;
    }
    for (const auto& pair : itemFrequencies) {
        outputStream << pair.first << " " << pair.second << endl;
    }
    outputStream.close();
}