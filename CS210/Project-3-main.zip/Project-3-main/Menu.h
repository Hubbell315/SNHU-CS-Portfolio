/**
 * @file Menu.h
 * @brief Declaration of the Menu class.
 *
 * This file contains the class declaration for the Menu class which
 * provides the user interface for the Corner Grocer application. It includes
 * methods for displaying menu options and getting validated user input.
 */

#ifndef MENU_H
#define MENU_H

#include <iostream>
#include <limits> 
#include <string> 

class Menu {
public:
    /**
     * @brief Displays the main menu options to the user.
     */
    void displayMenu() const;

    /**
     * @brief Prompts the user for a menu choice and validates the input.
     * @return The valid integer choice made by the user.
     */
    int getUserChoice() const;
};

#endif